#include <queue>
#include <climits>
#include <set>
#include <fstream>
#include <map>

#include "graph.h"

/**
 * A graph is made up of vertices and edges
 * A vertex can be connected to other vertices via weighted, directed edge
 */


////////////////////////////////////////////////////////////////////////////////
// This is 80 characters - Keep all lines under 80 characters                 //
////////////////////////////////////////////////////////////////////////////////


/** constructor, empty graph */
Graph::Graph() {
    numberOfVertices = 0;
    numberOfEdges = 0;
    vertices.clear();
}

/** destructor, delete all vertices and edges
    only vertices stored in map
    no pointers to edges created by graph */
Graph::~Graph() {}

/** return number of vertices */
int Graph::getNumVertices() const { 
    return static_cast<int>(vertices.size()); 
}

/** return number of edges */
int Graph::getNumEdges() const { 
    return numberOfEdges; 
}

/** add a new edge between start and end vertex
    if the vertices do not exist, create them
    calls Vertex::connect
    a vertex cannot connect to itself
    or have multiple edges to another vertex */
bool Graph::add(std::string start, std::string end, int edgeWeight) {
    Vertex* startVertex = nullptr;
    if (vertices.count(start) != 0) {
        startVertex = vertices[start];
    } else {
        startVertex = new Vertex(start);
        vertices[start] = startVertex;
    }
    return startVertex->connect(end, edgeWeight);
}

/** return weight of the edge between start and end
    returns INT_MAX if not connected or vertices don't exist */
int Graph::getEdgeWeight(std::string start, std::string end) const {
    if (vertices.count(start) == 0 || vertices.count(end) == 0) {
        return INT_MAX;
    }
    Vertex* startVertex = vertices.at(start);
    Vertex* endVertex = vertices.at(end);
    if (startVertex->isConnected(end) == false) {
        return INT_MAX;
    }
    return startVertex->getEdgeWeight(end);
}

/** read edges from file
    the first line of the file is an integer, indicating number of edges
    each edge line is in the form of "string string int"
    fromVertex  toVertex    edgeWeight */
void Graph::readFile(std::string filename) {
    std::ifstream filestream(filename);
    filestream >> numberOfEdges;
    std::string startVertex, endVertex;
    int edgeWeight;
    for (int i = 0; i < numberOfEdges; ++i) {
        filestream >> startVertex >> endVertex >> edgeWeight;
        vertices.insert(std::pair<std::string, Vertex*>
                        (startVertex, new Vertex(startVertex)));
        vertices.insert(std::pair<std::string, Vertex*>
                        (endVertex,  new Vertex(endVertex)));
        add(startVertex, endVertex, edgeWeight);
    }
    filestream.close();
}

/** depth-first traversal starting from startLabel
    call the function visit on each vertex label */
void Graph::depthFirstTraversal(std::string startLabel,
                                void visit(const std::string&)) {
    Graph::unvisitVertices();
    Vertex* startVertex = vertices[startLabel];
    Graph::depthFirstTraversalHelper(startVertex, visit);
}

/** breadth-first traversal starting from startLabel
    call the function visit on each vertex label */
void Graph::breadthFirstTraversal(std::string startLabel,
                                  void visit(const std::string&)) {
    Graph::unvisitVertices();
    Vertex* startVertex = vertices[startLabel];
    Graph::breadthFirstTraversalHelper(startVertex, visit);
}

/** find the lowest cost from startLabel to all vertices that can be reached
    using Djikstra's shortest-path algorithm
    record costs in the given map weight
    weight["F"] = 10 indicates the cost to get to "F" is 10
    record the shortest path to each vertex using given map previous
    previous["F"] = "C" indicates get to "F" via "C"

    cpplint gives warning to use pointer instead of a non-const map
    which I am ignoring for readability */
void Graph::djikstraCostToAllVertices(
    std::string startLabel,
    std::map<std::string, int>& weight,
    std::map<std::string, std::string>& previous) {
    auto startVertex = vertices[startLabel];
    auto u = startVertex->getFirstNeighbor();
    for (; u != startVertex->getLastNeighbor(); 
            u = startVertex->getNextNeighbor()) {
        weight[u] = startVertex->getEdgeWeight(u);
        previous[u] = startVertex->getLabel();
        pq.push(std::pair<std::string, int>(u, weight[u]));
    }
    vertexSet.insert(startVertex);
    while(!pq.empty()) {
        auto v = vertices[pq.top().first];
        pq.pop();
        if (!vertexSet.count(v)) {
            vertexSet.insert(v);
            auto u = v->getFirstNeighbor();
            for (; u != v->getLastNeighbor(); u = v->getNextNeighbor()) {
                if (vertexSet.count(vertices[u])) {
                    continue;
                }
                auto v2ucost = v->getEdgeWeight(u);
                if (!weight.count(u)) {
                    weight[u] = weight[v->getLabel()] + v2ucost;
                    previous[u] = v->getLabel();
                    pq.push(std::pair<std::string, int>(u, weight[u]));
                } else {
                    if (weight[u] > weight[v->getLabel()] + v2ucost) {
                        weight[u] = weight[v->getLabel()] + v2ucost;
                        previous[u] = v->getLabel();
                        pq.push(std::pair<std::string, int>(u, weight[u]));
                    }
                }
            }
        }
    }
    // If a vertex is unreachable, mark weight as INT_MAX
    for (const auto& iter : vertices) {
        if (iter.first != startVertex->getLabel() 
                && !vertexSet.count(iter.second)) {
            weight[iter.first] = INT_MAX;
        }
    }
}

/** helper for depthFirstTraversal */
void Graph::depthFirstTraversalHelper(Vertex* startVertex,
                                      void visit(const std::string&)) {
    if (startVertex->isVisited() == true) {
        return ;
    }
    startVertex->visit();
    visit(startVertex->getLabel());
    auto neighbor = startVertex->getFirstNeighbor();
    if (neighbor == startVertex->getLabel()) {
        return ;
    }
    for (; neighbor != startVertex->getLastNeighbor(); 
            neighbor = startVertex->getNextNeighbor()) {
        Vertex* currentNeighbor = vertices[neighbor];
        if (currentNeighbor->isVisited() == false) {
            depthFirstTraversalHelper(currentNeighbor, visit);
        }
    }
}

/** helper for breadthFirstTraversal */
void Graph::breadthFirstTraversalHelper(Vertex* startVertex,
                                        void visit(const std::string&)) {
    vertexQueue.push(startVertex);
    startVertex->visit();
    while (!vertexQueue.empty()) {
        Vertex* currentVertex = vertexQueue.front();
        vertexQueue.pop();
        visit(currentVertex->getLabel());
        auto neighbor = currentVertex->getFirstNeighbor();
        if (neighbor == currentVertex->getLabel()) {
            continue;
        }
        for (; neighbor != currentVertex->getLastNeighbor(); 
                neighbor = currentVertex->getNextNeighbor()) {
            Vertex* currentNeighbor = vertices[neighbor];
            if (currentNeighbor->isVisited() == false) {
                currentNeighbor->visit();
                vertexQueue.push(currentNeighbor);
            }
        }
    }
}

/** mark all verticies as unvisited */
void Graph::unvisitVertices() {
    for (auto& [str, ver] : vertices) {
        ver->unvisit();
    }
}

/** find a vertex, if it does not exist return nullptr */
Vertex* Graph::findVertex(const std::string& vertexLabel) const {
    if (vertices.count(vertexLabel)) {
        return vertices.at(vertexLabel);
    }
    return nullptr;
}

/** find a vertex, if it does not exist create it and return it */
Vertex* Graph::findOrCreateVertex(const std::string& vertexLabel) {
    if (vertices.count(vertexLabel)) {
        return vertices.at(vertexLabel);
    }
    Vertex* newVertex = new Vertex(vertexLabel);
    vertices[vertexLabel] = newVertex;
    return newVertex;
}
