# Usage
```bash
g++ -std=c++17 assignment3.cpp graph.cpp vertex.cpp edge.cpp
./a.out
```
